## Preprocessing Video Datasets for AdaScan

* Change the directories in preprocessing.py (specified in the '__main__' block)
* Run the script
