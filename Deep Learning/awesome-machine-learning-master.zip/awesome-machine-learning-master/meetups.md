The following is a list of free-to-attend meetups and local events on Machine Learning

- [India](#india)
    -   [Bangalore](#bangalore)

<a name="india" />
## India

<a name="bangalore" />
### Bangalore
* [Bangalore Machine Learning Meetup (BangML)](https://www.meetup.com/BangML/)
