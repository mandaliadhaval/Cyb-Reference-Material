The following is a list of free or paid online courses on machine learning, statistics, data-mining, etc.

## Machine-Learning / Data Mining

* [Artificial Intelligence (Columbia University)](https://www.edx.org/course/artificial-intelligence-ai-columbiax-csmm-101x) - free
* [Machine Learning (Columbia University)](https://www.edx.org/course/machine-learning-columbiax-csmm-102x) - free
* [Machine Learning (Stanford University)](https://www.coursera.org/learn/machine-learning) - free
* [Neural Networks for Machine Learning (University of Toronto)](https://www.coursera.org/learn/neural-networks) - free
* [Machine Learning Specialization (University of Washington)](https://www.coursera.org/specializations/machine-learning) - Courses: Machine Learning Foundations: A Case Study Approach, Machine Learning: Regression, Machine Learning: Classification, Machine Learning: Clustering & Retrieval, Machine Learning: Recommender Systems & Dimensionality Reduction,Machine Learning Capstone: An Intelligent Application with Deep Learning; free
* [Machine Learning Course (2014-15 session) (by Nando de Freitas, University of Oxford)](https://www.cs.ox.ac.uk/people/nando.defreitas/machinelearning/) - Lecture slides and video recordings.
* [Learning from Data (by Yaser S. Abu-Mostafa, Caltech)](http://www.work.caltech.edu/telecourse.html) - Lecture videos available
